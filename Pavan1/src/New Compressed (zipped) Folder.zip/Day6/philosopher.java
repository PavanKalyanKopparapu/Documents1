package Day6;

public class philosopher {
    public philosopher(int i, semaphore chopstic, semaphore chopstic1) {
    }
}
