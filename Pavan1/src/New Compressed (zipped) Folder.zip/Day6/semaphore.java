package Day6;

public class semaphore {
}
