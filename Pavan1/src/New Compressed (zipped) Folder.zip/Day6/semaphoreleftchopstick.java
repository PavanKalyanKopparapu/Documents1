package Day6;

public class semaphoreleftchopstick {
}
