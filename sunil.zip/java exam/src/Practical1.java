import java.util.Scanner;

public class Practical1 {
    public static void main(String[] args) {
        int a ,b;
    }
      //  System.out.println("Enter number of operations:5");
        Scanner sc = new Scanner(System.in);
        System.out.println("Operation type :1");
        int a=sc.nextInt();
        while (true)
        {
            System.out.println("Even");

           // else
            {
                System.out.println("Odd");
            }
        }
        System.out.println("Operation type :2");
        while(a && b)
        {
            isprime()
        }
        System.out.println("Operation type :3");
        System.out.println("Operation type :1");
        System.out.println("Operation type :2");

    }
}
